# Import for the Web Bot
from botcity.web import WebBot, Browser, By
import xlsxwriter
from openpyxl import load_workbook
from datetime import datetime
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import os
from PIL import Image

# Import for integration with BotCity Maestro SDK
from botcity.maestro import *
from webdriver_manager.chrome import ChromeDriverManager

# Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

class Bot(WebBot):

    def configurar_bot(self):
        self.headless = False
        self.browser = Browser.CHROME
        self.driver_path = ChromeDriverManager().install()

    def url_site(self, url="https://www.google.com.br"):
        try:
            self.browse(url)
            self.maximize_window()
        except Exception as ex:
            print("Erro ao acessar a url da página..")
            self.save_screenshot('erro.png')

    def pesquisar_temperatura(self, clima):
        #descomentar para utilizar esse trecho caso você já esteja logado no site da google
        #while len(self.find_elements('//*[@id="halloween-static"]', By.XPATH)) < 1:
            #self.wait(2000)
            #print('carregando.')

        #descomentar para usar este trecho caso você não esteja logado no site do google
        while len(self.find_elements('/html/body/div[1]/div[2]/div/img', By.XPATH)) < 1:    
            self.wait(2000)
            print('carregando.')
        
        self.find_element('//*[@id="APjFqb"]', By.XPATH).send_keys(clima)
        self.wait(2000)
        self.enter()

    def extrair_dados(self):
        dados_climaticos = []
        i = 0
        while True:
            i += 1
            self.find_element(f'//*[@id="wob_dp"]/div[{i}]', By.XPATH).click()
            self.wait(200)
            dia_semana = self.find_element(f'//*[@id="wob_dp"]/div[{i}]/div[1]', By.XPATH).text
            self.wait(200)
            max_temp = self.find_element(f'//*[@id="wob_dp"]/div[{i}]/div[3]/div[1]/span[1]', By.XPATH).text
            self.wait(200)
            min_temp = self.find_element(f'//*[@id="wob_dp"]/div[{i}]/div[3]/div[2]/span[1]', By.XPATH).text
            self.wait(200)
            umidade = self.find_element(f'/html/body/div[3]/div/div[13]/div/div[2]/div[2]/div/div/div[1]/div/div/div/div/div[1]/div[2]/div[2]/span', 
                                        By.XPATH).text
            self.wait(200)
            
            dados_climaticos.append({'Dia': dia_semana, 'Máximo': int(max_temp), 'Mínimo': int(min_temp), 'Umidade': int(umidade.strip('%'))})
            
            print(f"Dia: {dia_semana} Max: {max_temp} Min: {min_temp} Umidade: {umidade}")
            
            if i == 8:
                break
        
        self.salvar_dados_planilha(dados_climaticos)

    def salvar_dados_planilha(self, dados_climaticos):
        resources = os.path.join(os.path.dirname(__file__), "resources")
        nome_arquivo = os.path.join(resources, "dados_climaticos.xlsx")

        try:
            wb = load_workbook(nome_arquivo)
            ws = wb.active

        except FileNotFoundError:
            self.criar_planilha_com_dados(nome_arquivo)
            wb = load_workbook(nome_arquivo)
            ws = wb.active

        for dado in dados_climaticos:
            ws.append([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), dado['Dia'], dado['Máximo'], 
                dado['Mínimo'], dado['Umidade']])

        wb.save(nome_arquivo)
        print("\nDados salvos no arquivo Excel.")

        self.gerar_grafico_de_dados(dados_climaticos)

    def criar_planilha_com_dados(self, nome_arquivo):
        wb = xlsxwriter.Workbook(nome_arquivo)
        sheet = wb.add_worksheet("Dados Climáticos")
        
        sheet.write(0, 0, "Data")
        sheet.write(0, 1, "Dia")
        sheet.write(0, 2, "Máximo")
        sheet.write(0, 3, "Mínimo")
        sheet.write(0, 4, "Umidade")

        wb.close()
        print(f"\nPlanilha criada: {nome_arquivo}")

    def gerar_grafico_de_dados(self, dados_climaticos):
        pasta_resources = os.path.join(os.path.dirname(__file__), "resources")
        caminho_imagem = os.path.join(pasta_resources, "grafico_variacao_climaticos.png")

        dias = [dado['Dia'] for dado in dados_climaticos]
        maximos = [dado['Máximo'] for dado in dados_climaticos]
        minimos = [dado['Mínimo'] for dado in dados_climaticos]
        umidades = [dado['Umidade'] for dado in dados_climaticos]

        plt.figure(figsize=(10, 6))
        plt.plot(dias, maximos, marker='o', label="Temperatura Máxima (°C)", color='red')
        plt.plot(dias, minimos, marker='o', label="Temperatura Mínima (°C)", color='blue')
        plt.plot(dias, umidades, marker='o', label="Umidade (%)", color='green')
        
        plt.title("Variação de Dados Climáticos")
        plt.xlabel("Dias da Semana")
        plt.ylabel("Valores")
        plt.legend()
        
        plt.savefig(caminho_imagem)
        print("\nGráfico de variação de dados climáticos gerado e salvo como imagem .png com sucesso")
    
    def exibir_imagem_grafico(self):
        pasta_resources = os.path.join(os.path.dirname(__file__), "resources")
        caminho_imagem = os.path.join(pasta_resources, "grafico_variacao_climaticos.png")

        imagem = mpimg.imread(caminho_imagem)
        plt.imshow(imagem)
        plt.axis('off')
        plt.show(block=False)
        plt.pause(6)
        plt.close()

    def action(self, execution=None):
        maestro = BotMaestroSDK.from_sys_args()
        execution = maestro.get_execution()

        print(f"Task ID is: {execution.task_id}")
        print(f"Task Parameters are: {execution.parameters}")

        try:
            dados_climaticos = "temperatura em Manaus uma semana"
            self.configurar_bot()
            self.url_site()
            self.pesquisar_temperatura(dados_climaticos)
            self.wait(2000)
            self.extrair_dados()
            self.exibir_imagem_grafico()

        except Exception as ex:
            print(f"Erro: {ex}")
            self.save_screenshot('erro.png')

        finally:    
            self.wait(3000)
            self.stop_browser()

            # Uncomment to mark this task as finished on BotMaestro
            # maestro.finish_task(
            #     task_id=execution.task_id,
            #     status=AutomationTaskFinishStatus.SUCCESS,
            #     message="Task Finished OK."
            # )

    def not_found(self, label):
        print(f"Element not found: {label}")


if __name__ == '__main__':
    Bot.main()
