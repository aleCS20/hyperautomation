#!/bin/bash

zip -r "bot_dados_climaticos.zip" * -x "bot_dados_climaticos.zip"