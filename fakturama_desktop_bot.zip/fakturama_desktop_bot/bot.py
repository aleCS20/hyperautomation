# Import for the Desktop Bot
from botcity.core import DesktopBot

# Import for integration with BotCity Maestro SDK
from botcity.maestro import *

import json

# Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

def carregar_json():
    with open('cadastrar_produto.json', 'r') as arquivo:
        produtos = json.load(arquivo)
    return produtos
        
def main():
    # Runner passes the server url, the id of the task being executed,
    # the access token and the parameters that this task receives (when applicable).
    maestro = BotMaestroSDK.from_sys_args()
    ## Fetch the BotExecution with details from the task, including parameters
    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")

    bot = DesktopBot()
    bot.execute(r"C:\Program Files\Fakturama2\Fakturama.exe")

    try:
        bot.wait(11000)

        #novo
        if not bot.find("titulo_fakturama", matching=0.97, waiting_time=10000):
            not_found("titulo_fakturama")
        bot.click_relative(64, -49)
        
        bot.wait(2000)
        #novo
        if not bot.find("descricao_produto", matching=0.97, waiting_time=10000):
            not_found("descricao_produto")
        bot.click_relative(121, 30)

        executar_json = carregar_json()
        print("")
        count = 0           
        for i, item in enumerate(executar_json):
            for produto in executar_json[item]['products']:
                count+=1
                item_number = produto['item_number']
                bot.paste(item_number)
                #bot.wait(1000)
                bot.tab()
                name = produto['name']
                bot.paste(name)
                #bot.wait(1000)
                bot.tab()
                category = produto['category']
                bot.paste(category)
                #bot.wait(1000)
                bot.tab()
                gtin = produto['gtin']
                bot.paste(gtin)
                #bot.wait(1000)
                bot.tab()
                supplier_code = produto['supplier_code']
                bot.paste(supplier_code)
                #bot.wait(1000)
                bot.tab()
                description = produto['description']
                bot.paste(description)
                #bot.wait(1000)
                bot.tab()
                price = produto['price']
                bot.paste(price)
                #bot.wait(1000)
                bot.tab()
                cost = produto['cost']
                bot.paste(cost)
                #bot.wait(1000)
                bot.tab()
                allowance = produto['allowance']
                bot.paste(allowance)
                #bot.wait(1000)
                bot.tab()
                vat = produto['vat']
                bot.paste(vat)
                #bot.wait(1000)
                bot.tab()
                stock = produto['stock']
                bot.paste(stock)
                bot.wait(2000)

                #salvar o produto cadastrado
                #novo
                if not bot.find("botao_salvar", matching=0.97, waiting_time=10000):
                    not_found("botao_salvar")
                bot.click()
                bot.wait(2000)

                if count <  2:
                                        
                    #adicionar novo produto
                    if not bot.find("botao_adicionar", matching=0.97, waiting_time=10000):
                        not_found("botao_adicionar")
                    bot.click()

                    #direcionar o clique no primero campo
                    if not bot.find("primeiro_campo", matching=0.97, waiting_time=10000):
                        not_found("primeiro_campo")
                    bot.click_relative(115, 29)

        bot.wait(2000)    
        bot.alt_f4()
              
                
    except Exception as ex:
        print(ex)
        bot.save_screenshot('erro.png')
   
    finally:
        bot.wait(2000)
        #bot.stop_browser()
    
    # Uncomment to mark this task as finished on BotMaestro
    # maestro.finish_task(
    #     task_id=execution.task_id,
    #     status=AutomationTaskFinishStatus.SUCCESS,
    #     message="Task Finished OK."
    # )

def not_found(label):
    print(f"Element not found: {label}")


if __name__ == '__main__':
    main()