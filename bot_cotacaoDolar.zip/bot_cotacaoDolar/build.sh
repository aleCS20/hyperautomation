#!/bin/bash

zip -r "bot_cotacaoDolar.zip" * -x "bot_cotacaoDolar.zip"