"""
WARNING:

Please make sure you install the bot dependencies with `pip install --upgrade -r requirements.txt`
in order to get all the dependencies on your Python environment.

Also, if you are using PyCharm or another IDE, make sure that you use the SAME Python interpreter
as your IDE.

If you get an error like:
```
ModuleNotFoundError: No module named 'botcity'
```

This means that you are likely using a different Python interpreter than the one used to install the dependencies.
To fix this, you can either:
- Use the same interpreter as your IDE and install your bot with `pip install --upgrade -r requirements.txt`
- Use the same interpreter as the one used to install the bot (`pip install --upgrade -r requirements.txt`)

Please refer to the documentation for more information at
https://documentation.botcity.dev/tutorials/python-automations/desktop/
"""

# Import for the Desktop Bot
from botcity.core import DesktopBot

# Import for the Web Bot
from botcity.web import WebBot, Browser, By

# Import for integration with BotCity Maestro SDK
from botcity.maestro import *

#imports for do chrome driver
from webdriver_manager.chrome import ChromeDriverManager

#imports for pandas
import pandas as pd

#import plot
import matplotlib.pyplot as plt

#import date e time
from datetime import date

#imports for openpyxl
import openpyxl

#imports for csv
import csv

# Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

def cookie(webbot):
    webbot.wait(2000)
    if webbot.find_element("/html/body/app-root/bcb-cookies", By.XPATH) is not None:
        prosseguir = webbot.find_element("/html/body/app-root/bcb-cookies/div/div/div/div/button[2]", By.XPATH)
        prosseguir.click()

def prencherDados(webbot, dataInicial, dataFinal):
    while len(webbot.find_elements('/html/body/app-root/app-root/div/div/main/dynamic-comp/div/h1',By.XPATH)) < 1:
        print("carregando....")
        webbot.wait(1000)

    webbot.wait(2000)

    iframe = webbot.find_element('/html/body/app-root/app-root/div/div/main/dynamic-comp/div/div[2]/div[1]/div/iframe', By.XPATH)
    webbot.enter_iframe(iframe)

    webbot.execute_javascript(f"""
            var campo1 = document.evaluate('/html/body/div/form/table[2]/tbody/tr[2]/td[2]/input', document, null, 
                    XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                campo1.value = '{dataInicial}';
            """)
    webbot.wait(2000)

    webbot.execute_javascript(f"""
            var campo2 = document.evaluate('/html/body/div/form/table[2]/tbody/tr[3]/td[2]/input', document, null, 
                    XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                campo2.value = '{dataFinal}';                 
            """)
    
    webbot.wait(1000)
    webbot.find_element('/html/body/div/form/div/input', By.XPATH).click()


def baixarCSV(webbot):
    while len(webbot.find_elements('/html/body/div/a',By.XPATH)) < 1:
        print("carregando....")
        webbot.wait(1000)
    webbot.find_element('/html/body/div/a',By.XPATH).click()
    webbot.wait(2000)
    webbot.stop_browser()

def main():
    # Runner passes the server url, the id of the task being executed,
    # the access token and the parameters that this task receives (when applicable).
    maestro = BotMaestroSDK.from_sys_args()
    ## Fetch the BotExecution with details from the task, including parameters
    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")

    desktop_bot = DesktopBot()

    # Execute operations with the DesktopBot as desired
    # desktop_bot.control_a()
    # desktop_bot.control_c()
    # value = desktop_bot.get_clipboard()

    webbot = WebBot()

    # Configure whether or not to run on headless mode
    webbot.headless = False

    # Uncomment to change the default Browser to Firefox
    webbot.browser = Browser.CHROME

    # Uncomment to set the WebDriver path
    # webbot.driver_path = "<path to your WebDriver binary>"
    webbot.driver_path = ChromeDriverManager().install()

    # Opens the BotCity website.
    webbot.browse(r"https://www.bcb.gov.br/estabilidadefinanceira/historicocotacoes")

    # Implement here your logic...
    try:
        cookie(webbot)
        prencherDados(webbot,'20/06/2024','20/07/2024')
        baixarCSV(webbot)
        webbot.wait(2000)
          
        cotacao_df = pd.read_csv("CotacoesMoedasPeriodo.csv",sep=";")
        headerList = ['Data','Codigo Moeda','Tipo moeda', 'Moeda', 'Compra', 'Venda', 'coluna A', 'Coluna b']
        cotacao_df.to_csv("CotacoesMoedasPeriodo2.csv", header=headerList, index=False)
        
        cotacao_df2 = pd.read_csv("CotacoesMoedasPeriodo2.csv")
        cotacao_df2=cotacao_df2[['Data','Compra','Venda']]
        cotacao_df2 = cotacao_df2.replace({',':'.'}, regex=True)  
        cotacao_df2['Compra']=cotacao_df2['Compra'].astype(float)
        cotacao_df2['Venda']=cotacao_df2['Venda'].astype(float)

        webbot.wait(1000)
        
        wb = openpyxl.Workbook()
        ws = wb.active

        with open('CotacoesMoedasPeriodo2.csv') as f:
            reader = csv.reader(f, delimiter=':')
            for row in reader:
                ws.append(row)
        
        wb.save('CotacoesMoedasPeriodo2.xlsx')

        print(cotacao_df2)
        cotacao_df2.plot()
        cotacao_df2.plot(x="Compra",y="Venda",kind="line")
        plt.show()

    except Exception as ex:
        print("Erro", ex)
        webbot.save_screenshot("erro.png")
    finally:
        # Wait 3 seconds before closing
        webbot.wait(4000)

        # Finish and clean up the Web Browser
        # You MUST invoke the stop_browser to avoid
        # leaving instances of the webdriver open
        #webbot.stop_browser()

        # Uncomment to mark this task as finished on BotMaestro
        # maestro.finish_task(
        #     task_id=execution.task_id,
        #     status=AutomationTaskFinishStatus.SUCCESS,
        #     message="Task Finished OK."
        # )

def not_found(label):
    print(f"Element not found: {label}")


if __name__ == '__main__':
    main()
