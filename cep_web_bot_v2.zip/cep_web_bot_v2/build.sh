#!/bin/bash

zip -r "cep_web_bot.zip" * -x "cep_web_bot.zip"