$exclude = @("venv", "cep_web_bot.zip")
$files = Get-ChildItem -Path . -Exclude $exclude
Compress-Archive -Path $files -DestinationPath "cep_web_bot.zip" -Force