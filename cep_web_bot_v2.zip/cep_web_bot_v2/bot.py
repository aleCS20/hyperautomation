# Import for the Web Bot
from botcity.web import WebBot, Browser, By

# Import for integration with BotCity Maestro SDK
from botcity.maestro import *

from webdriver_manager.chrome import ChromeDriverManager
from botcity.plugins.http import BotHttpPlugin
from botcity.web.util import element_as_select
from botcity.web.parsers import table_to_dict

import pandas as pd
import requests

# Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

chave = "57428462782c3df7b88e53018233f31d"

def solucionando_captcha(imagem, bot):

    with open(imagem, "rb") as arquivo:
        resposta = requests.post("http://2captcha.com/in.php", data={
            'key': chave,
            'method': 'post',
            'json': 1
        }, files={'file': arquivo})

    identificador = resposta.json().get('request')

    solucao = None
    while True:
        resultado = requests.get(f"http://2captcha.com/res.php?key={chave}&action=get&id={identificador}&json=1")
        if resultado.json().get('status') == 1:
            solucao = resultado.json().get('request')
            break
        print("Solucionando captcha...")
        bot.wait(3000)

    return solucao

def ler_dados_cep(bot):
    bot.browse("https://buscacepinter.correios.com.br/app/endereco/index.php")
    bot.wait(3000)
    bot.maximize_window()

    #lendo arquivo .xlsx com ceps
    planilha = pd.read_excel('ceps.xlsx')

    dados_cep = []
       
    for cep in planilha['Cep']:
        bot.find_element('endereco', By.ID).send_keys(str(cep))
        bot.wait(1000)

        select = bot.find_element(selector='tipoCEP', by=By.ID)
        select = element_as_select(select)

        #campo de tipo
        select.select_by_value(value='ALL')
        bot.wait(1000)

        #tirando foto do captcha para resolução
        captcha = bot.find_element('//*[@id="captcha_image"]', By.XPATH)
        captcha.screenshot("captcha.png")

        #campo de captcha
        bot.find_element('//*[@id="captcha"]', By.XPATH).click()
        bot.wait(5000)

        #chamada de função de tipo solucionar captcha
        captcha_resolvido = solucionando_captcha("captcha.png", bot)

        bot.find_element('//*[@id="captcha"]', By.XPATH).send_keys(captcha_resolvido)
        bot.wait(5000)

        #realizar pesquisa do cep atual
        bot.find_element('//*[@id="btn_pesquisar"]', By.XPATH).click()
        bot.wait(2000)
        
        logradouro, bairro, localidade, cep_ = recuperar_valores(bot)

        dados_cep.append((logradouro, bairro, localidade, cep_))
        
        bot.navigate_to('https://buscacepinter.correios.com.br/app/endereco/index.php')

    return dados_cep

def recuperar_valores(bot):
    while len(bot.find_elements('/html/body/main/div[1]/a[2]/b', By.XPATH))<1:
        bot.wait(2000)
        print('carregando....')

    table_element = bot.find_element('//*[@id="resultado-DNEC"]', By.XPATH)
    table_data = table_to_dict(table=table_element)

    for row in table_data:
        return (row['logradouronome'], row['bairrodistrito'], row['localidadeuf'], row['cep'])
    

def main():
    maestro = BotMaestroSDK.from_sys_args()

    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")

    bot = WebBot()

    bot.headless = False

    bot.browser = Browser.CHROME

    bot.driver_path = ChromeDriverManager().install()

    bot.browse("https://buscacepinter.correios.com.br/app/endereco/index.php")

    try:
        dados_cep = ler_dados_cep(bot)    
        print(dados_cep)

        df = pd.DataFrame(dados_cep, columns=['logradouronome', 'bairrodistrito', 'localidadeuf', 'cep'])

        df.to_excel('relatorio_cep.xlsx', index=False)

        print("Arquivo com os dados de ceps criado com sucesso!!!!!!!!!")

    except Exception as ex:
        print(ex)
        bot.save_screenshot('erro.png')
    finally:
        bot.wait(2000)
        bot.stop_browser()

def not_found(label):
    print(f"Element not found: {label}")

if __name__ == '__main__':
    main()
